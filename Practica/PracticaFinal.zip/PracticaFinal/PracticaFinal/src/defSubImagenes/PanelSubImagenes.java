/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package defSubImagenes;

import Interfaces.BarraProgresionTemporal;
import defPartida.Partida;
import java.awt.Color;
import java.awt.GridLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;
import java.util.Random;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.swing.BorderFactory;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.border.LineBorder;
import static PracticaFinal.GestorEventos.divisionesHorizontales;
import static PracticaFinal.GestorEventos.divisionesVerticales;
import static PracticaFinal.GestorEventos.nombreJugador;
import static PracticaFinal.LecturaDatos.partidaEnCurso;
import PracticaFinal.PracticaFinal;

/**
 *
 * @author Blanca e Irene
 */
public class PanelSubImagenes extends JPanel { //en esta clase que es un JPanel
    //se crea una cuadrícula de JLabel hecha de JLabel llamada imag y sobre ella se pintan las 
    //imágenes.

    private JLabel[] imag;
    private static JLabel[] subimagenes;
    private int[] contenedorNumeroImagenes; //array que nos servirán para poder desordenar de manera random
    //las imagenes. ContenedorNumeroImagenes será para desordenarla y contenedorNumeroImagenesOrdenada está ordenado
    private int[] contenedorNumeroImagenesOrdenada;
    private JLabel subimagen1; //atributos que nos servirán para hacer los cambios, son los 2 JLabel que serán intercambiadasm
    //es decir, podemos decir que son 2 piezas de puzzle. 
    private JLabel subimagen2;
    private static Thread progresoThread;
    public static BarraProgresionTemporal barraTemporal;

    private int r;
    private int c;

    public PanelSubImagenes(String imagen, int hori, int verti) throws NullPointerException  {

        try {
            try {
                //contructor
                imag = new SubImagen(imagen).getImagRecortadas(); //en el array imag se guardará las imagenes
                //que se han recortado gracias a la clase Subimagen. 
            } catch (IOException ex) {
                Logger.getLogger(PanelSubImagenes.class.getName()).log(Level.SEVERE, null, ex);
            }
            contenedorNumeroImagenes = new int[new SubImagen(imagen).getImagRecortadas().length]; //en el array
            //se guarda el tamaño de las subimagnes recortadas. 
            contenedorNumeroImagenesOrdenada = new int[new SubImagen(imagen).getImagRecortadas().length];
            this.r = hori;
            this.c = verti;
            setup();
            initComponents();
        } catch (IOException ex) {
            Logger.getLogger(PanelSubImagenes.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NullPointerException ex){
           
        }
    }

    private void setup() {
        setLayout(new GridLayout(r, c, 5, 5)); //se inicializa la tabla en JPanel según 
        //el número de filas y columnas que se instancian. 
        setSize(785 - (r * 5), 520 - (c * 5)); //IMPORTANTE ESTO HACE QUE CAMBIE LA CUADRÍCULA 
        setBackground(Color.BLACK);
        setVisible(true);
    }

    private void initComponents() {
        Random ran = new Random(); //se elige de manera random para 

        int numero = imag.length;
        subimagenes = new JLabel[imag.length];

        int numAleat = ran.nextInt(0, numero - 1);
        for (int indice = 0; indice < numero; indice++) {
            contenedorNumeroImagenesOrdenada[indice] = indice;

            while (imagenColocada(numAleat)) {
                numAleat = ran.nextInt(numero);
            }
            contenedorNumeroImagenes[indice] = numAleat;
//            add(imag[numAleat]);
            subimagenes[indice] = imag[numAleat];
            add(subimagenes[indice]);

//            add(subimagenes[numAleat]);  
//            imag[numAleat].addMouseListener(new CustomMouseListener());
            numAleat = ran.nextInt(0, numero - 1);
        }

        for (int indice = 0; indice < numero; indice++) {
            subimagenes[indice].addMouseListener(new CustomMouseListener());

        }
//        subimagenes[numAleat].addMouseListener(new CustomMouseListener());

        if (ultimNumero() != -1) {
            add(imag[ultimNumero()]);
        }
        barraTemporal = new BarraProgresionTemporal(500);
        progresoThread = new Thread(new Runnable() {
            @Override
            public void run() {
                // Actualizamos la barra de progreso en incrementos hasta llegar al 100%
                for (int i = 0; i <= 100; i++) {
                    barraTemporal.setValorBarraTemporal(i);

                    try {
                        Thread.sleep(r * c * 15);
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }

                JOptionPane.showMessageDialog(null, "NO LO HAS CONSEGUIDO - EL TIEMPO HA TERMINADO");
                Partida gout = new Partida("resultados.dat", nombreJugador, 0);
                gout.inserirRegistre();                
                PracticaFinal.panelContenidos.panelImagenSolucion(); //se pone la solucion con la imagen entera sin cortes
                partidaEnCurso = false;

            }
        });
        progresoThread.start();

    }

    private boolean imagenColocada(int numero) {
        for (int i = 0; i < contenedorNumeroImagenes.length - 1; i++) {

            if (contenedorNumeroImagenes[i] == numero) {
                return true;
            }
        }
        return false;
    }

    private int ultimNumero() {
        for (int i = 0; i < contenedorNumeroImagenes.length; i++) {
            for (int j = 0; j < contenedorNumeroImagenes.length; j++) {

                if (contenedorNumeroImagenesOrdenada[j] != contenedorNumeroImagenes[i]) {
                    return contenedorNumeroImagenesOrdenada[j];
                }
            }
        }
        return -1;
    }

//    public MouseListener eventosRaton(String Nombre) {
//        MouseListener accion = new MouseListener() {
//            @Override
//            public void mousePressed(MouseEvent evento) {
//
//            }
//
//            @Override
//            public void mouseClicked(MouseEvent e) {
//
//            }
//
//            @Override
//            public void mouseReleased(MouseEvent e) {
//            }
//
//            @Override
//            public void mouseEntered(MouseEvent e) {
//            }
//
//            @Override
//            public void mouseExited(MouseEvent e) {
//            }
//        };
//        return accion;
//    }
    private class CustomMouseListener extends MouseAdapter { //estos métodos se usan para intercambiar las imágenes

        public void mousePressed(MouseEvent e) { //subiamgen1 y subimagen2 son como digamos piezas de puzzle 
            JLabel source = (JLabel) e.getSource();
            if (subimagen1 == null) {
                // Guardar la primera subimagen seleccionada
                subimagen1 = source; //se guarda las posiciones y atributos de la subimagen 1 seleccionada.
                subimagen1.setBorder(BorderFactory.createLineBorder(Color.RED, 2)); //cuando se selecciona
                //se pone un borde rojo para saber cual se selecciona. 
            } else if (subimagen1 == source) {
                subimagen1 = source; //se guarda las posiciones y atributos de la subimagen 1 seleccionada.
                subimagen1.setBorder(BorderFactory.createLineBorder(Color.RED, 2)); //cuando se selecciona
                //se pone un borde rojo para saber cual se selecciona. 
            } else if (subimagen2 == null) {
                // Guardar la segunda subimagen seleccionada
                subimagen2 = source; //se guarda las posiciones y atributos de las subiamgen 2 seleccionada.
                // Intercambiar la posición y la imagen
                intercambiarPosiciones(subimagen1, subimagen2);

                // Reiniciar las variables de selección
                subimagen1 = null;
                subimagen2 = null;
            }
        }
    }

    private void intercambiarPosiciones(JLabel subimagen1, JLabel subimagen2) { //se intercambia las imagenes
        // Obtener las posiciones actuales de las subimágenes
        int pos1 = -1;
        int pos2 = -1;
        for (int i = 0; i < subimagenes.length; i++) {
            if (subimagenes[i] == subimagen1) {
                pos1 = i;
            } else if (subimagenes[i] == subimagen2) {
                pos2 = i;
            }
        }

        // Intercambiar las posiciones en subimagenes
        JLabel temp = subimagenes[pos1];
        subimagenes[pos1] = subimagenes[pos2];
        subimagenes[pos2] = temp;

        this.subimagen1 = subimagenes[pos1];
        this.subimagen2 = subimagenes[pos2];
        //se pone el borde en blanco de las subiamgenes intercambiadas 
        subimagen1.setBorder(BorderFactory.createCompoundBorder(
                new LineBorder(java.awt.Color.WHITE),
                new EmptyBorder(2, 2, 2, 2)
        ));

        actualizartabla();
    }

    private void actualizartabla() { //se repinta y se actualiza la tabla con los cambios de las 2 subimagenes , es decir, 
        //las dos piezas del puzzle ya cambiadas. 
        removeAll();
        if (!sonArreglosIguales(imag, subimagenes)) { //si no se ha llegado a la solucion final 
            for (JLabel subimagen : subimagenes) {
                if (subimagen != null) {
                    add(subimagen);
                }
            }

        } else {  //si se ha ganado , entonces se pinta la imagen solucionada. 
            for (JLabel subimagen : subimagenes) {
                if (subimagen != null) {
                    add(subimagen);
                }
            }
            progresoThread.stop();
            JOptionPane.showMessageDialog(null, "HAS GANADO " + divisionesHorizontales * divisionesVerticales + " PUNTOS!!!! \nENHORABUENA!!!!"); //si ha 
            //ganado sale un mensaje para anunciarlo. 

            Partida gout = new Partida("resultados.dat", nombreJugador, divisionesHorizontales * divisionesVerticales);
            gout.inserirRegistre(); //se registra en el fichero de "resulatdos.dat"
            PracticaFinal.panelContenidos.panelImagenSolucion(); //se pone la solucion con la imagen entera sin cortes
            partidaEnCurso = false;
        }
        revalidate();
        repaint();
    }

    private static boolean sonArreglosIguales(JLabel[] array1, JLabel[] array2) { //comprueba si el array de imag y subimagenes 
        //que está desordenado son iguales, si es así, significa que se ha llegado a la solucion. Sino debe seguir pintando 
        //las desordenadas. 
        for (int i = 0; i < array1.length; i++) {
            if (!array1[i].equals(array2[i])) {
                return false;
            }
        }
        return true;
    }

}
