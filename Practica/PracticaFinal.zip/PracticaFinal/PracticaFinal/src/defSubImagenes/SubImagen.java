/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package defSubImagenes;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import PracticaFinal.GestorEventos;
import static PracticaFinal.LecturaDatos.partidaEnCurso;
import PracticaFinal.PracticaFinal;

/**
 *
 * @author Blanca e Irene
 */
public class SubImagen extends JPanel { //clase que es un JPanel para cuando tenemos la imagen seleccionada dividirla en
    //diferentes partes. 

    private String nameFile; //nombre del fichero de la imagen
    private JLabel[] imagRecortadas; //array que contiene las imagenes recortadas
    private int rows;
    private int cols;
    private BufferedImage scaledImage; //buffered para escalar la imagen

    public SubImagen(String image) throws IOException {//constructor
        rows = GestorEventos.divisionesHorizontales;
        cols = GestorEventos.divisionesVerticales;

        this.setBackground(Color.BLACK);
        nameFile = image;
        imagRecortadas = null;
        if (partidaEnCurso == true) {
            dividirimag(); //método para dividir la imagen 
        } else {
            PracticaFinal.panelContenidos.initComponents();
        }
    }

    public void dividirimag() throws IOException, NullPointerException {
        FileInputStream fis = null;
        escalarimagen(nameFile);

        int chunks = rows * cols;

        int chunkWidth = scaledImage.getWidth() / cols; // determina el chunk altura y ancho
        int chunkHeight = scaledImage.getHeight() / rows;
        int count = 0;
        BufferedImage imgs[] = new BufferedImage[chunks]; //Image array to hold image chunks
        for (int x = 0; x < rows; x++) { //doble duble para inicilaizar el array de la imagen con la imagen chunks
            for (int y = 0; y < cols; y++) {

                imgs[count] = new BufferedImage(chunkWidth, chunkHeight, scaledImage.getType());

                //dibuja la imagen chunk
                Graphics2D gr = imgs[count++].createGraphics();
                gr.drawImage(scaledImage, 0, 0, chunkWidth, chunkHeight, chunkWidth * y, chunkHeight * x, chunkWidth * y + chunkWidth, chunkHeight * x + chunkHeight, null);
                gr.dispose();
            }
        }

        imagRecortadas = new JLabel[imgs.length]; //guarda las imagenes en un array de JLabel
        for (int i = 0; i < imgs.length; i++) {
            imagRecortadas[i] = new JLabel(new ImageIcon(imgs[i]));
        }

    }

    public static BufferedImage scaleImage(BufferedImage originalImage, int targetWidth, int targetHeight) {
        BufferedImage scaledImage = new BufferedImage(targetWidth, targetHeight, BufferedImage.TYPE_INT_RGB);
        Graphics2D g2d = scaledImage.createGraphics();
        g2d.drawImage(originalImage, 0, 0, targetWidth, targetHeight, null);
        g2d.dispose();
        return scaledImage;
    }

    public void escalarimagen(String nameFile) throws IOException, NullPointerException { //antes de dividir la imagen, es necesario escalarla
        //para que así se hagan las divisiones correctamente. 
        FileInputStream fis = null;
        // Cargar la imagen original en un BufferedImage
        File file = new File(nameFile); // 
        try {
            fis = new FileInputStream(file);
            BufferedImage imagesinescalar = ImageIO.read(fis); //reading the image file
            // Escalar la imagen original
            scaledImage = scaleImage(imagesinescalar, 785, 520);

        } catch (FileNotFoundException ex) {
            Logger.getLogger(SubImagen.class.getName()).log(Level.SEVERE, null, ex);
        } catch (IOException ex) {
            Logger.getLogger(SubImagen.class.getName()).log(Level.SEVERE, null, ex);
        } catch (NullPointerException ex) {

        } finally {
            fis.close();
        }
    }

    public JLabel[] getImagRecortadas() {
        return imagRecortadas;
    }

    public String getFile() {
        return nameFile;
    }

}
