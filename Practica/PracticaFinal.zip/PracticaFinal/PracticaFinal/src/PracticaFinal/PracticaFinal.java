/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package PracticaFinal;

import Interfaces.PanelContenidos;
import java.awt.BorderLayout;
import javax.swing.JFrame;

/**
 * 1ª en ordenador de Blanca,26/5/23
 * @author Blanca e Irene
 */
public class PracticaFinal extends JFrame {
    //Clase principal con el main 

    public static final PanelContenidos panelContenidos = new PanelContenidos(); 
    public static final PracticaFinal frame = new PracticaFinal(); 
    
    public static void main(String[] args) {
        frame.setVisible(true);
    }  

    private PracticaFinal() {
        setTitle("TALLER 2 - PROGRAMACION II - 2022-2023 - UIB"); //título contenedor pruebaBotones
        setSize(1000, 660);
        
        setResizable(false);
        setLayout(new BorderLayout()); //asignación de Layaout BorderLayout
        setLocationRelativeTo(null);
        
        
        
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setContentPane(panelContenidos); //asignación a panelContenidos del panel de contenidos del JFrame
    }
    
}
