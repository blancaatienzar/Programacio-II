/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package PracticaFinal;

import java.awt.event.ActionListener;
import java.io.File;
import java.util.Random;
import javax.swing.JComponent;
import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import static PracticaFinal.LecturaDatos.partidaEnCurso;

/**
 *
 * @author Irene Blokker y Blanca Atienzar
 */
public class GestorEventos { //esta clase la usaremos como dice el nombre para gestionar eventos principalmente con

    //AcctionListeners. 
    public static String nombreJugador;
    public static int divisionesHorizontales, divisionesVerticales;
    public static String RutaDirectorio = "puzzlefotos";

    public static class RutaPredeterminadaEliminada extends Exception{
        public RutaPredeterminadaEliminada(String msg){
            JOptionPane.showMessageDialog(null,
                msg);
        }
    }
    public GestorEventos() {

    }

    public ActionListener crearPartida() {
        return e -> {
            if (!partidaEnCurso) {
                introducirDatos();
            } else {
                JOptionPane.showMessageDialog(null, "ANTES DEBES TERMINAR LA\n"
                        + "PARTIDA EN CURSO");
            }
        };
    }

    public ActionListener estadisticas() {
        return e -> {
            if (!partidaEnCurso) {
                PracticaFinal.panelContenidos.Historial(null);
            } else {
                JOptionPane.showMessageDialog(null, "ANTES DEBES TERMINAR LA\n"
                        + "PARTIDA EN CURSO");
            }
        };
    }

    public ActionListener estadisticasUsuario() {
        return e -> {
            if (!partidaEnCurso) {
                String nomJugador = JOptionPane.showInputDialog(" HISTORIAL JUGADOR \n INTRODUCIR NOMBRE DEL JUGADOR");
                PracticaFinal.panelContenidos.Historial(nomJugador);
            } else {
                JOptionPane.showMessageDialog(null, "ANTES DEBES TERMINAR LA\n"
                        + "PARTIDA EN CURSO");
            }
        };
    }

    public ActionListener cambiarDirectorio(JComponent clase) {
        return e -> {

            if (!partidaEnCurso) {
                obtenerDirectorio(clase);
            } else {
                JOptionPane.showMessageDialog(null, "ANTES DEBES TERMINAR LA\n"
                        + "PARTIDA EN CURSO");
            }
        };
    }

    private void obtenerDirectorio(JComponent clase) {
        JFileChooser chooser = new JFileChooser();
        chooser.setFileSelectionMode(JFileChooser.DIRECTORIES_ONLY);
        chooser.setDialogTitle("SELECCIONA EL DIRECTORIO DESEADO");
        chooser.setCurrentDirectory(new File(RutaDirectorio));

        int op = chooser.showOpenDialog(null);

        if (op != JFileChooser.CANCEL_OPTION) {
            File fileName = chooser.getSelectedFile();
            if ((fileName == null) || (fileName.getName().equals(""))) {
                JOptionPane.showMessageDialog(null,
                        " LO SENTIMOS\n"
                        + " EL DIRECTORIO NO SE HA CAMBIADO");

            } else {
                RutaDirectorio = fileName.getPath();
                JOptionPane.showMessageDialog(null,
                        " EL DIRECTORIO SE HA CAMBIADO");
            }
        }
    }

    public ActionListener exit() {
        return e -> {
            if (!partidaEnCurso) {
                System.exit(0);
            } else {
                JOptionPane.showMessageDialog(null, "ANTES DEBES TERMINAR LA\n"
                        + "PARTIDA EN CURSO");
            }

        };
    }

    private boolean introducirDatos() {
        String[] infointroduccionDatos = {"NOMBRE JUGADOR", "NÚMERO DE SUBDIVISIONES HORIZONTAL", "NÚMERO DE SUBDIVISIONES VERTICAL"};
        //String en donde se guardan los "enunciados" de las preguntas que se quieren preguntar. 
        infointroduccionDatos = new LecturaDatos(PracticaFinal.frame, infointroduccionDatos).getDatosTexto();
        //llamamos a la clase LecturaDatos para leer los datos que introduce el usuario. 

        if (infointroduccionDatos != null) {
            nombreJugador = infointroduccionDatos[0]; //en el String nombreJugador guardaremos aquello guardado en la primera 
            //casilla del String. 
            divisionesHorizontales = Integer.parseInt(infointroduccionDatos[1]);
            divisionesVerticales = Integer.parseInt(infointroduccionDatos[2]);

            if (0 > divisionesHorizontales || 0 > divisionesVerticales || divisionesVerticales == ' '
                    || divisionesHorizontales == ' ' || nombreJugador == null) {
                entradaIncorrecta(); //controlar lo introducido por el usuario 
                return false;
            }

            PracticaFinal.panelContenidos.Partida(divisionesHorizontales, divisionesVerticales);

            return true;
        } else {
            entradaIncorrecta();
            return false;
        }

    }

    private void entradaIncorrecta() {
        JOptionPane.showMessageDialog(PracticaFinal.frame, //contenedor padre
                "¡¡¡ NO HAS INTRODUCIDO LOS DATOS CORRECTAMENTE\n"
                + "    PARA INICIAR UNA PARTIDA !!!"//texto visualizado
        );
        PracticaFinal.panelContenidos.initComponents();
    }

    private static boolean validarFile(String nombreFile) {

        int x = nombreFile.length() - 5;
        if (((nombreFile.charAt(x + 1) == '.') && (nombreFile.charAt(x + 2) == 'j') && (nombreFile.charAt(x + 3) == 'p') && (nombreFile.charAt(x + 4) == 'g'))
                || ((nombreFile.charAt(x + 1) == '.') && (nombreFile.charAt(x + 2) == 'g') && (nombreFile.charAt(x + 3) == 'i') && (nombreFile.charAt(x + 4) == 'f'))
                || ((nombreFile.charAt(x + 1) == '.') && (nombreFile.charAt(x + 2) == 'p') && (nombreFile.charAt(x + 3) == 'n') && (nombreFile.charAt(x + 4) == 'g'))
                || ((nombreFile.charAt(x) == '.') && (nombreFile.charAt(x + 1) == 'j') && (nombreFile.charAt(x + 2) == 'p') && (nombreFile.charAt(x + 3) == 'e') && (nombreFile.charAt(x + 4) == 'g'))) {
            return true;
        }
        return false;

    }

    //este método se usará para elegir una foto de manera random en el directorio indicado, y la foto seleccionada, 
    //será la que salga en esta partida respectiva. Se ha decidido implementarla aqui debido a que se debe elegir la foto 
    //en el momento en el que se da al botón de confirmar cuando se piden los datos. 
    public static String elegirfotorandom() throws RutaPredeterminadaEliminada {
        
        File carpeta = new File(RutaDirectorio);
        
        if (!carpeta.exists() || !carpeta.isDirectory()) {
        throw new RutaPredeterminadaEliminada("La carpeta 'puzzlefotos' no existe. Elige otra carpeta");
        
    }
        
        File[] archivos = carpeta.listFiles();
        Random random = new Random();
        File archivoAleatorio;
        String nombreSoloFoto;
        try {
            if (archivos.length == 0) {
                RutaDirectorio = "puzzlefotos";
                carpeta = new File(RutaDirectorio);
                archivos = carpeta.listFiles();
                JOptionPane.showMessageDialog(null, "COMO NO SE HA PODIDO OBTENER NINGUNA IMAGEN \n"
                        + "SE HA VUELTO AL DIRECTORIO PREDETERMINADO");
            }
        } catch (Exception e) {
        }
        
         File carpeta1 = new File(RutaDirectorio);
        
        if (!carpeta1.exists() || !carpeta1.isDirectory()) {
        throw new RutaPredeterminadaEliminada("La carpeta 'puzzlefotos' no existe. Elige otra carpeta");
        
    }
        
        archivoAleatorio = archivos[random.nextInt(archivos.length)];
        nombreSoloFoto = archivoAleatorio.getName();

        try {
            if (!validarFile(nombreSoloFoto)) {
                for (int i = 0; i < archivos.length; i++){
                    archivoAleatorio = archivos[i];
                    nombreSoloFoto = archivoAleatorio.getName();
                    if (validarFile(nombreSoloFoto)) {
                        return (RutaDirectorio + "/" + nombreSoloFoto);
                        
                    }
                }
                RutaDirectorio = "puzzlefotos";
                carpeta1 = new File(RutaDirectorio);
                archivos = carpeta1.listFiles();
                archivoAleatorio = archivos[random.nextInt(archivos.length)];
                nombreSoloFoto = archivoAleatorio.getName();
                JOptionPane.showMessageDialog(null, "NO SE HA PODIDO OBTENER NINGUNA IMAGEN \n"
                        + "SE HA VUELTO AL DIRECTORIO PREDETERMINADO");
            }
        } catch (Exception e) {
        }

        return (RutaDirectorio + "/" + nombreSoloFoto);
    }

}
