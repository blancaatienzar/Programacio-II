package PracticaFinal;

/*
autor : Irene Y Blanca
 */
import java.awt.Color;
import java.awt.Container;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class LecturaDatos extends JDialog {
//Esta clase se usará cuando el usuario haya hecho clik en la opción de Nueva Partida, el cual deberá de 
    //pedirle su nombre, numero de divisiones horizontales y verticales que desea, que posteriormente, esta información será 
    //enviada tanto para ser guardada en el fichero de "resultados.dat" como en el juego para saber el numero de divisiones

    //atributo array de componentes JTextField que representarán los valores
    //introducidos a través del contenedor JDialog
    private JTextField[] datos; //en este array se guardarán los datos que introduzca el usuario
    //atributo entero que representa el número de valores a introducir a traves
    //del contenedor JDialog
    private int numeroValores = 0;
    private Integer numHorizontal;
    private Integer numVertical;
    public static String nombreFoto;
    public static boolean partidaEnCurso = false;

    private ActionListener gestorEvento;

    //MÉTODO CONSTRUCTOR
    //el parámetro frame representa el contenedor JFrame desde el que se le ha
    //llevado a cabo la instanciación, y el parámetro campos representan los
    //literales de los conceptos demandados para introducir     
    public LecturaDatos(JFrame frame, String[] campos) {

        super(frame, true);
        setTitle("INTRODUCCIÓN DATOS");

        //el número de componentes de campos (número de conceptos) representa
        //el número de valores a introducir
        numeroValores = campos.length;

        Container panelContenidos = getContentPane();
        //asignación al panel de contenidos del administrador de layout
        //GridLayout estructurado en (numeroValores+1) filas y una
        //columna

        panelContenidos.setLayout(new GridLayout(numeroValores + 1, 1));
        datos = new JTextField[numeroValores];

        JLabel[] conceptos = new JLabel[numeroValores];
//en el array de JLabel se escribirán los "enunciados" de las preguntas, nombre, numero de divisiones horizontales y verticales
        JPanel[] paneles = new JPanel[numeroValores];
        try {
            for (int indice = 0; indice < datos.length; indice++) {
                //instanciación de los diferentes arrays 
                conceptos[indice] = new JLabel(campos[indice]);
                conceptos[indice].setForeground(Color.white);
                conceptos[indice].setFont(new Font("Arial", Font.BOLD, 18));
                datos[indice] = new JTextField(5);
                datos[indice].setText("");
                datos[indice].setHorizontalAlignment(JTextField.LEFT);
                paneles[indice] = new JPanel();
                paneles[indice].setBackground(Color.black);
                paneles[indice].setLayout(new GridLayout());
                //introducción en el contenedor JPanel indice-ésimo de la 
                //componente JLabel indice-ésima y de la componente JTextField
                //indice-ésima
                paneles[indice].add(conceptos[indice]);
                paneles[indice].add(datos[indice]);
                //introducción del contenedor JPanel indice-ésimo en el
                //panel de contenidos del contenedor JDialog
                panelContenidos.add(paneles[indice]);
            }
        } catch (NumberFormatException e) {
            System.out.println("Error en el número de divisiones");
        }

//declaración componente JButton salirBoton
        JButton confirmarBoton = new JButton("CONFIRMAR");
        panelContenidos.add(confirmarBoton);
        //Al pulsar el botón de CONFIRMAR pasará a presentarse el juego. Que se encuentra en PanelContenidos, 
        //por tanto se instancia la clase mediante el AcctionListener a través del botón. 
        confirmarBoton.addActionListener(gestorEvento = new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                try {
                    partidaEnCurso = true;
                    PracticaFinal.panelContenidos.initComponents();

                    nombreFoto = GestorEventos.elegirfotorandom();
                    setVisible(false);
                } catch (GestorEventos.RutaPredeterminadaEliminada rp) {
                    partidaEnCurso = false;
                    PracticaFinal.panelContenidos.initComponents();
                }
            }
        });
        setSize(900, numeroValores * 50);
        setLocationRelativeTo(frame);
        setVisible(true);
    }
    

    public String[] getDatosTexto() { //en este método se guardan los datos introducidos y se controla si da error o se 
        //introduce correctamente.
        String[] datosIntroducidos = new String[numeroValores];
        for (int indice = 0; indice < datosIntroducidos.length; indice++) {
            //asignamos a la componente indice del array datosIntroducidos el
            //String introducido en la componente JTextField del array datos

            datosIntroducidos[indice] = (datos[indice].getText());
            if (datos[indice].getText().equals("")) {
                JOptionPane.showMessageDialog(null, "ENTRADA INCORRECTA");
                partidaEnCurso = false;
                return null;
            }

        }
        try {
            int numHoriz = Integer.parseInt(datosIntroducidos[1]);
            int numVert = Integer.parseInt(datosIntroducidos[2]);

            if (numHoriz == 1 && numVert == 1) {
                JOptionPane.showMessageDialog(null, "El número de divisiones no puede ser 1 x 1");
                partidaEnCurso = false;
                return null;
            }

            if (numHoriz == 0 || numVert == 0) {
                JOptionPane.showMessageDialog(null, "El número de divisiones no puede ser 0");
                partidaEnCurso = false;
                return null;
            }
            
            if (numHoriz > 50 || numVert > 50) {
            JOptionPane.showMessageDialog(null, "El número de divisiones no puede ser tan grande");
            partidaEnCurso = false;
            return null;
        }

            numHorizontal = numHoriz;
            numVertical = numVert;
        } catch (NumberFormatException e) {
            JOptionPane.showMessageDialog(null, "Error en el número de divisiones");
            partidaEnCurso = false;
            return null;
        }

        return datosIntroducidos;
    }

    public String getNombreJugador() {
        return datos[0].getText();
    }

    public int getNumHoriz() {
        return numHorizontal;
    }

    public int getNumVert() {
        return numVertical;
    }

}
