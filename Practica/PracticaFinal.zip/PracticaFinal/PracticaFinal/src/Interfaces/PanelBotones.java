/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template

Autor Irene Y Blanca 
 */
package Interfaces;

import PracticaFinal.GestorEventos;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import javax.swing.JButton;
import javax.swing.JPanel;

/**
 * hecho sin funciones
 * @author Blanca
 */
public class PanelBotones extends JPanel{ //Panel en donde se guarda los Botones 
    private GestorEventos event = new GestorEventos();
    
    public PanelBotones() { //contructor
        setup();
        initComponents();
    }

    private void setup() {
        setLayout(new GridLayout(4, 1));
    }

    /**
     * Metodo que inicializa los diferente componentes botones del PanelBotones
     * 
     */
    private void initComponents() {

        //COMPONENTE JButton 
        JButton nuevaPartidaBoton = new JButton("NUEVA PARTIDA");
        nuevaPartidaBoton.setFont(new Font("arial", Font.BOLD, 11));
        nuevaPartidaBoton.setForeground(Color.WHITE);
        nuevaPartidaBoton.setBackground(Color.BLACK);
        nuevaPartidaBoton.addActionListener(event.crearPartida());
        add("CREAR", nuevaPartidaBoton);

        //COMPONENTE JButton 
        JButton clasificacionBoton = new JButton("CLASIFICACIÓN GENERAL");
        clasificacionBoton.setFont(new Font("arial", Font.BOLD, 11));
        clasificacionBoton.setForeground(Color.WHITE);
        clasificacionBoton.setBackground(Color.BLACK);
        clasificacionBoton.addActionListener(event.estadisticas());
        add("REPRODUCIR", clasificacionBoton);

        //COMPONENTE JButton 
        JButton historialBoton = new JButton("HISTORIAL");
        historialBoton.setFont(new Font("arial", Font.BOLD, 11));
        historialBoton.setForeground(Color.WHITE);
        historialBoton.setBackground(Color.BLACK);
        historialBoton.addActionListener(event.estadisticasUsuario());
        add("ADIVINAR", historialBoton);

        //COMPONENTE JButton salirBoton
        JButton salirBoton = new JButton("SALIR");
        salirBoton.setFont(new Font("arial", Font.BOLD, 11));
        salirBoton.setForeground(Color.WHITE);
        salirBoton.setBackground(Color.BLACK);
        salirBoton.addActionListener(event.exit());
        add("SALIR", salirBoton);
    }

}

