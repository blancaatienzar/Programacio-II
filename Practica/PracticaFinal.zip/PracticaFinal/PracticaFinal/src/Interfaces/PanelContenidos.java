/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template

Autor: Irene y Blanca
 */
package Interfaces;

import defPartida.Partida;
import defSubImagenes.PanelSubImagenes;
import static defSubImagenes.PanelSubImagenes.barraTemporal;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JSplitPane;
import static PracticaFinal.GestorEventos.nombreJugador;
import static PracticaFinal.LecturaDatos.nombreFoto;
import PracticaFinal.PracticaFinal;

/**
 *
 * @author Blanca
 */
public class PanelContenidos extends JPanel { //Clase en el que se hace la organizacion para los paneles. 

    private final JSplitPane separador1 = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
    private final JSplitPane separador2 = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
    private final JSplitPane separador3 = new JSplitPane(JSplitPane.HORIZONTAL_SPLIT);
    private final JSplitPane separador4 = new JSplitPane(JSplitPane.VERTICAL_SPLIT);


    public PanelContenidos() {
        setup();
        initComponents();

    }

    public void setup() {
        setLayout(new BorderLayout());
    }

    /**
     * Metodo que inizializa la interfaz principal que visualiza PanelImagen
     * (UIB) y PanelFondo (que contiene la etiqueta titulo)
     */
    public void initComponents() { //Panel principal con la imagen de la UIB

        separador1.setLeftComponent(new Menu());
        separador1.setDividerLocation(60);
        separador1.setEnabled(false);

        separador3.setLeftComponent(new PanelBotones());

        separador3.setRightComponent(new PanelVisualizaciones(null).panelStandby());
        separador3.setEnabled(false);

        separador1.setRightComponent(separador3);

        separador2.setLeftComponent(separador1);

        add(separador2);
    }

    public void panelImagenSolucion() { //Panel principal en donde aparece la imagen ya solucionada cuando el usuario ha 
//        ganado o ha abandonado la partida 
    
        separador4.setLeftComponent(new PanelVisualizaciones(null).panelImagenSolucione(nombreFoto));
        separador4.setDividerLocation(500);

        separador4.setEnabled(false);

        JButton Continuar = new JButton("CONTINUAR");
        Continuar.setForeground(Color.WHITE);
        Continuar.setBackground(Color.BLACK);
        separador4.setDividerLocation(500);
      
        separador4.setRightComponent(Continuar);
        separador3.setLeftComponent(new PanelBotones());

        Continuar.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                PracticaFinal.panelContenidos.initComponents();
            }
        });
        
        separador3.setRightComponent(separador4);
        separador3.revalidate();
        separador3.repaint();

    }
    
    
//      public void panelImagenSolucion() { //Panel principal en donde aparece la imagen ya solucionada cuando el usuario ha 
//        //ganado o ha abandonado la partida 
//        
//        separador1.setLeftComponent(new Menu());
//        separador1.setDividerLocation(60);
//        separador1.setEnabled(false);
//
//        separador3.setLeftComponent(new PanelBotones());
//
//        separador4.setLeftComponent(new PanelVisualizaciones(null).panelImagenSolucion(nombreFoto));
//        separador4.setDividerLocation(500);
//
//        separador4.setEnabled(false);
//
//        JButton Continuar = new JButton("CONTINUAR");
//        Continuar.setForeground(Color.WHITE);
//        Continuar.setBackground(Color.BLACK);
//
//        Continuar.addActionListener(new ActionListener() {
//            @Override
//            public void actionPerformed(ActionEvent e) {
//                PracticaFinal.panelContenidos.initComponents();
//            }
//        });
//
//        separador4.setRightComponent(Continuar);
//        separador3.setRightComponent(separador4);
//        separador1.setRightComponent(separador3);
//        separador2.setLeftComponent(separador1);
//
//        add(separador2);
//    }

    public void Partida(int hori, int verti) { //Panel principal en donde aparece la foto para jugar la partida dividida. 

        separador4.setLeftComponent(new PanelSubImagenes(nombreFoto, hori, verti));
        separador4.setDividerLocation(505);
        separador4.setEnabled(false);
        separador4.setDividerLocation(500);
        separador4.setEnabled(false);

        separador4.setRightComponent(barraTemporal);
        separador3.setLeftComponent(new PanelBotones());
        
        separador3.setRightComponent(separador4);
        separador3.revalidate();
        separador3.repaint();

    }

    public void Historial(String nombreUsuario) { //Panel principal en donde se ve el historial.

        separador3.setLeftComponent(new PanelBotones());
        separador3.setRightComponent(new PanelVisualizaciones(nombreUsuario).panelHistorial());
        
        separador3.revalidate();
        separador3.repaint();
    }

}
