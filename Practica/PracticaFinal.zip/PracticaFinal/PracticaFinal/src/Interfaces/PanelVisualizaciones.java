/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template

Autor: Irene Y Blanca
 */
package Interfaces;

import defPartida.Partida;
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import static PracticaFinal.GestorEventos.nombreJugador;

/**
 *
 * @author Blanca
 */
public class PanelVisualizaciones extends JPanel { //será el panel en donde aparece tanto la imagen de la UIB, como la imagen
    //solucionada como la imagen para jugar dividida así como el historial. 

    private JTextArea areaVisualizacionResultados;
    private String nombreUsuario;

    public PanelVisualizaciones(String nom) {
        nombreUsuario = nom;
        setVisible(true);
        setLayout(new BorderLayout());
    }

    public JPanel panelHistorial() {
        JPanel panelHistorial = new JPanel();
        panelHistorial.setVisible(true);
        panelHistorial.setLayout(new BorderLayout());

        //try {
        if (nombreUsuario == null) {
            Partida gout = new Partida("resultados.dat", nombreJugador, 22);
            
            areaVisualizacionResultados = new JTextArea();
            areaVisualizacionResultados.setText("\n\tHISTORIAL\n\n" + gout.contingutFitxer());
            areaVisualizacionResultados.setFont(new Font("Monospaced", 1, 20));
        } else {
            Partida gout = new Partida("resultados.dat", nombreJugador, 22);
            
            areaVisualizacionResultados = new JTextArea();
            areaVisualizacionResultados.setText("\n\tHistorial Especifico\n\n" + 
                    gout.filtreNombre(nombreUsuario));
            areaVisualizacionResultados.setFont(new Font("Monospaced", 1, 20));
        }

        JScrollPane scrollPane = new JScrollPane(areaVisualizacionResultados);
        scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_ALWAYS);

        panelHistorial.add(scrollPane, BorderLayout.CENTER);

        panelHistorial.setVisible(true);

        return panelHistorial;
    }

    public JPanel panelStandby() { //panel donde aparece la imgen de la UIB
        JPanel panelStandby = new JPanel();
        panelStandby.setVisible(true);
        panelStandby.setBackground(Color.BLACK);
        panelStandby.setLayout(new BorderLayout());
        JLabel imagenUIB;
        try {
            imagenUIB = new JLabel(new ImageIcon(ImageIO.read(new File("imagenes/UIB.jpg")).getScaledInstance(935, 600, 4)));
            imagenUIB.setBackground(Color.BLACK);
            imagenUIB.setBorder(BorderFactory.createEmptyBorder());
            panelStandby.add(imagenUIB);
        } catch (IOException e) {
            System.out.println("ERROR ");
        }
        add(panelStandby);
        return panelStandby;
    }

    public JPanel panelPartida() {
        JPanel panelPartida = new JPanel();

        return panelPartida;
    }

    public JPanel panelImagenSolucione(String imag) { //panel con la solucion
        JPanel panelImagenSolucion = new JPanel();
        panelImagenSolucion.setVisible(true);
        panelImagenSolucion.setBackground(Color.BLACK);
        panelImagenSolucion.setLayout(new BorderLayout());
        JLabel imagenUIB;
        try {
            imagenUIB = new JLabel(new ImageIcon(ImageIO.read(new File(imag)).getScaledInstance(935, 600, 4)));
            imagenUIB.setBackground(Color.BLACK);
            imagenUIB.setBorder(BorderFactory.createEmptyBorder());
            panelImagenSolucion.add(imagenUIB);
        } catch (IOException e) {
            System.out.println("ERROR ");
        }
        add(panelImagenSolucion);
        return panelImagenSolucion;
    }
}
