/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template

Autor: Irene Y Blanca 
 */
package Interfaces;

import java.awt.BorderLayout;
import PracticaFinal.GestorEventos;
import java.awt.Color;
import java.awt.FlowLayout;
import java.io.File;
import java.io.IOException;
import javax.imageio.ImageIO;
import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JToolBar;

/**
 *
 * @author Blanca
 */
public class Menu extends JPanel {
    
    private BarraMenu barraMenu;
    private IconosMenu iconosMenu;

    public Menu() {
        setLayout(new BorderLayout());
        barraMenu = new BarraMenu();
        iconosMenu = new IconosMenu();
        add(barraMenu, BorderLayout.NORTH);
        add(iconosMenu, BorderLayout.CENTER);
    }

    public class BarraMenu extends JMenuBar {
        private GestorEventos event = new GestorEventos();
        
        public BarraMenu() {
            this.setBackground(Color.BLACK);
            this.setOpaque(true);
            initComponents();
        }

        private void initComponents() {
            ////////DECLARACIÓN DE LAS COMPONENTES JMenu ASOCIADAS A barraMenu
            JMenu menu = new JMenu("MENU");
            menu.setForeground(Color.WHITE);
            menu.setBackground(Color.BLACK);
            menu.setOpaque(true);

            ////////COMPONENTES JMenuItem asociadas a la componente JMenu generalMenu
            //DECLARACIONES COMPONENTES JMenuItem ASOCIADAS A generalMenu
            JMenuItem nuevaPartidaMenu = new JMenuItem("NUEVA PARTIDA");
            nuevaPartidaMenu.addActionListener(event.crearPartida());
            nuevaPartidaMenu.setForeground(Color.WHITE);
            nuevaPartidaMenu.setBackground(Color.BLACK);

            JMenuItem clasificacionMenu = new JMenuItem("CLASIFICACIÓN GENERAL");
            clasificacionMenu.addActionListener(event.estadisticas());
            clasificacionMenu.setForeground(Color.WHITE);
            clasificacionMenu.setBackground(Color.BLACK);

            JMenuItem historialMenu = new JMenuItem("HISTORIAL");
            historialMenu.addActionListener(event.estadisticasUsuario());
            historialMenu.setForeground(Color.WHITE);
            historialMenu.setBackground(Color.BLACK);

            JMenuItem cambiarDirectorioMenu = new JMenuItem("CAMBIAR DIRECTORIO DE IMAGENES");
            cambiarDirectorioMenu.addActionListener(event.cambiarDirectorio(this));
            cambiarDirectorioMenu.setForeground(Color.WHITE);
            cambiarDirectorioMenu.setBackground(Color.BLACK);

            JMenuItem salirMenu = new JMenuItem("SALIR");
            salirMenu.addActionListener(event.exit());
            salirMenu.setForeground(Color.WHITE);
            salirMenu.setBackground(Color.BLACK);
            
            //inclusión de las componentes JMenuItem a la componente 
            //JMenu generalMenu
            menu.add(nuevaPartidaMenu);
            menu.add(clasificacionMenu);
            menu.add(historialMenu);
            menu.add(cambiarDirectorioMenu);
            menu.add(salirMenu);

            //INLCUSIÓN MENUS EN LA BARRA DE MENUS
            add(menu);
        }
    }

    public class IconosMenu extends JToolBar {

        private JButton nuevaPartidaIcono, clasificacionIcono, historialIcono, cambiarDirectorioIcono, salirIcono;
        private GestorEventos event = new GestorEventos();

        public IconosMenu() {
            setup();
            initComponents();
        }

        public void setup() {
            setLayout(new FlowLayout(FlowLayout.LEFT));
            setBackground(Color.BLACK);
            this.setRollover(true);
            this.setOpaque(true);
        }

        public void initComponents() {
            try {
                nuevaPartidaIcono = new JButton(new ImageIcon(ImageIO.read(new File("imagenes/iconoNuevaPartida.jpg"))));
                nuevaPartidaIcono.setBackground(Color.BLACK);
                nuevaPartidaIcono.setBorder(BorderFactory.createEmptyBorder());
                nuevaPartidaIcono.addActionListener(event.crearPartida());
                add(nuevaPartidaIcono);
            } catch (IOException e) {
                System.out.println("ERROR ");
            }
            try {
                clasificacionIcono = new JButton(new ImageIcon(ImageIO.read(new File("imagenes/iconoHistorialSelectivo.jpg"))));
                clasificacionIcono.setBackground(Color.BLACK);
                clasificacionIcono.setBorder(BorderFactory.createEmptyBorder());
                clasificacionIcono.addActionListener(event.estadisticas());
                add(clasificacionIcono);
            } catch (IOException e) {
                System.out.println("ERROR ");
            }
            try {
                historialIcono = new JButton(new ImageIcon(ImageIO.read(new File("imagenes/iconoHistorialGeneral.jpg"))));
                historialIcono.setBackground(Color.BLACK);
                historialIcono.setBorder(BorderFactory.createEmptyBorder());
                historialIcono.addActionListener(event.estadisticasUsuario());
                add(historialIcono);
            } catch (IOException e) {
                System.out.println("ERROR ");
            }
            try {
                cambiarDirectorioIcono = new JButton(new ImageIcon(ImageIO.read(new File("imagenes/iconoCambiarDIrectorio.jpg"))));
                cambiarDirectorioIcono.setBackground(Color.BLACK);
                cambiarDirectorioIcono.setBorder(BorderFactory.createEmptyBorder());
                cambiarDirectorioIcono.addActionListener(event.cambiarDirectorio(this));
                add(cambiarDirectorioIcono);
            } catch (IOException e) {
                System.out.println("ERROR ");
            }
            try {
                salirIcono = new JButton(new ImageIcon(ImageIO.read(new File("imagenes/iconoSalir.jpg"))));
                salirIcono.setBackground(Color.BLACK);
                salirIcono.setBorder(BorderFactory.createEmptyBorder());
                salirIcono.addActionListener(event.exit());
                add(salirIcono);
            } catch (IOException e) {
                System.out.println("ERROR ");
            }
        }
    }
}
